"""Synthetic timing probe only; not an accuracy or training-result experiment."""
import json
import time
import torch
from edge_lab.models import Classifier, STUDENTS

torch.set_num_threads(4)
for name in ('resnet50',) + STUDENTS:
    model = Classifier(name, 100).to(memory_format=torch.channels_last).train()
    images = torch.randn(32, 3, 32, 32).contiguous(memory_format=torch.channels_last)
    labels = torch.randint(0, 100, (32,))
    optimizer = torch.optim.SGD(model.parameters(), lr=0.01)
    times = []
    for step in range(5):
        start = time.perf_counter()
        optimizer.zero_grad(set_to_none=True)
        torch.nn.functional.cross_entropy(model(images), labels).backward()
        optimizer.step()
        if step:
            times.append(time.perf_counter() - start)
    print(json.dumps({'architecture': name, 'batch': 32, 'seconds_per_train_step': sum(times) / len(times),
                      'estimated_45000_image_epoch_seconds': sum(times) / len(times) * 45000 / 32,
                      'synthetic_probe_only': True}), flush=True)
    del model, optimizer
