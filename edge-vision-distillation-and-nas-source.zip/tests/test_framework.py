import json
import numpy as np
import pytest
import torch
from edge_lab.models import Classifier, SearchCNN, STUDENTS
from edge_lab.losses import DistillationLoss
from edge_lab.nas import constraint_violations


@pytest.fixture(autouse=True)
def small_threads():
    torch.set_num_threads(2)


@pytest.mark.parametrize('architecture',('resnet50',)+STUDENTS)
def test_required_architectures_support_cifar_and_backprop(architecture):
    model=Classifier(architecture,100).train()
    features,logits=model.features_logits(torch.randn(2,3,32,32))
    assert logits.shape==(2,100) and features.shape[1]==model.feature_channels
    torch.nn.functional.cross_entropy(logits,torch.tensor([1,9])).backward()
    assert any(p.grad is not None for p in model.parameters())


def test_joint_kd_detaches_teacher_but_trains_projector():
    student=torch.randn(2,7,requires_grad=True);teacher=torch.randn(2,7,requires_grad=True)
    features=torch.randn(2,8,4,4,requires_grad=True);targets=torch.randn(2,16,2,2,requires_grad=True)
    loss_function=DistillationLoss(8,16,temperature=3,alpha=.6,beta=2)
    loss,parts=loss_function(student,teacher,torch.tensor([1,4]),features,targets)
    expected=(1-.6)*parts['hard']+.6*parts['soft']+2*parts['feature']
    torch.testing.assert_close(loss.detach(),expected)
    loss.backward()
    assert teacher.grad is None and targets.grad is None
    assert student.grad.abs().sum()>0 and features.grad.abs().sum()>0
    assert loss_function.projector.weight.grad.abs().sum()>0


@pytest.mark.parametrize('resolution',[16,24,32])
def test_config_generated_networks(resolution):
    configuration={'resolution':resolution,'blocks':[
        {'channels':16,'kernel':7,'operation':'separable','activation':'silu'},
        {'channels':32,'kernel':3,'operation':'conv','activation':'relu6'}]}
    assert SearchCNN(configuration)(torch.randn(2,3,resolution,resolution)).shape==(2,10)


def test_constraints_reject_measured_values_and_preserve_unsupported_memory():
    limits={'max_latency_p95_ms':10,'max_model_bytes':1000,'max_peak_memory_bytes':5000}
    assert constraint_violations({'latency_p95_ms':11,'model_bytes':1001,'peak_memory_bytes':5001},limits)==[
        'latency','storage','process_peak_memory']
    assert constraint_violations({'latency_p95_ms':2,'model_bytes':900,'peak_memory_bytes':None},limits)==[]


def test_real_onnx_cpu_parity_and_isolated_measurement(tmp_path):
    from edge_lab.deploy import export_model,measure_model
    configuration={'resolution':16,'blocks':[
        {'channels':16,'kernel':3,'operation':'separable','activation':'relu'},
        {'channels':24,'kernel':5,'operation':'conv','activation':'hardswish'}]}
    path=tmp_path/'candidate.onnx'
    evidence=export_model(Classifier('nas',10,nas_config=configuration),16,path)
    assert evidence['parity_samples']==3 and evidence['parity_max_absolute_error']<.001
    measured=measure_model(path,16,threads=2,repeats=5)
    assert measured['provider']=='CPUExecutionProvider' and measured['model_bytes']==path.stat().st_size
    assert len(measured['raw_latency_ms'])==5 and measured['latency_p95_ms']>0


def test_smoke_is_never_submission(tmp_path,monkeypatch):
    from edge_lab import submission
    monkeypatch.setattr(submission,'ROOT',tmp_path)
    (tmp_path/'results').mkdir()
    (tmp_path/'results/run_manifest.json').write_text(json.dumps({'status':'training_complete','configuration':{'smoke':True}}))
    with pytest.raises(RuntimeError,match='smoke checks cannot be submitted'):
        submission.validate()


def test_data_split_is_disjoint_stratified_and_ignores_test_statistics(tmp_path,monkeypatch):
    from edge_lab import data
    class FakeCIFAR:
        filename='test.tar.gz'
        def __init__(self,root,train,download):
            self.classes=[str(i) for i in range(10)]
            self.targets=list(range(10))*50 if train else list(range(10))
            self.data=np.random.default_rng(1).integers(0,100,size=(len(self.targets),32,32,3),dtype=np.uint8) if train else np.full((10,32,32,3),255,dtype=np.uint8)
        def __len__(self):return len(self.targets)
    monkeypatch.setattr(data.datasets,'CIFAR10',FakeCIFAR)
    monkeypatch.setattr(data,'ROOT',tmp_path)
    dataset=data.CIFARData('cifar10',data_root=tmp_path)
    assert len(dataset.train_indices)==450 and len(dataset.val_indices)==50
    assert set(dataset.train_indices).isdisjoint(dataset.val_indices)
    assert len(set(dataset.train_indices)|set(dataset.val_indices))==500
    expected=dataset.training.data[dataset.train_indices].astype(np.float64).mean((0,1,2))/255
    np.testing.assert_allclose(dataset.mean,expected,atol=1e-12)
    counts=np.bincount(np.array(dataset.training.targets)[dataset.val_indices])
    assert np.all(counts==5)


def test_package_excludes_credentials_environment_and_executables(tmp_path,monkeypatch):
    import zipfile
    from edge_lab import submission
    project=tmp_path/'project';output=tmp_path/'run'
    project.mkdir();output.mkdir()
    for filename,value in [('README.md','instructions'),('.env','SECRET_TOKEN=never-include'),('helper.exe','binary')]:
        (project/filename).write_text(value)
    for folder in ['models','results','onnx']:(output/folder).mkdir()
    (output/'models/teacher.pt').write_bytes(b'unit test artifact, not trained weights')
    (output/'models/nas_trial_0.pt').write_bytes(b'exclude temporary trial')
    (output/'results/benchmarks.csv').write_text('model,latency\n')
    (output/'results/secrets.env').write_text('PRIVATE')
    monkeypatch.setattr(submission,'ROOT',output);monkeypatch.setattr(submission,'PROJECT',project)
    # Required-artifact validation has separate tests; exercise only ZIP collection here.
    monkeypatch.setattr(submission,'validate',lambda:None)
    destination=submission.package()
    with zipfile.ZipFile(destination) as archive:
        assert archive.testzip() is None
        names=archive.namelist()
        assert 'edge_vision/models/teacher.pt' in names
        assert not any(n.endswith(('.env','.exe')) or 'nas_trial_' in n for n in names)
