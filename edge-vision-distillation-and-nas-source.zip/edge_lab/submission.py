"""Validate required artifacts before making the roll-number submission ZIP."""
import json
import zipfile
from pathlib import Path
from .common import ROOT, PROJECT, sha256, write_json, timestamp
from .models import STUDENTS


def validate():
    names=[a+'_'+mode for a in STUDENTS for mode in ('baseline','kd')]+['nas_best']
    manifest=json.loads((ROOT/'results'/'run_manifest.json').read_text())
    if manifest['status']!='training_complete' or manifest['configuration'].get('smoke'):
        raise RuntimeError('Submission requires a completed full-data experiment; smoke checks cannot be submitted.')
    required=['results/hardware.json','results/benchmarks.csv','results/benchmarks.json',
        'results/best_architecture.json','results/nas_search_history.csv','results/nas_search_history.json',
        'results/nas_final_verification.json','output/pdf/edge_vision_report.pdf',
        'docs/screenshots/recorded_results.png','docs/screenshots/inference.png','results/inference_examples.json']
    for name in ['teacher']+names:
        required += [f'models/{name}.pt',f'results/{name}_metrics.json',f'results/{name}_history.csv']
        metric=json.loads((ROOT/f'results/{name}_metrics.json').read_text())
        if metric['training_samples']!=45000 or metric['validation_samples']!=5000 or metric['test']['samples']!=10000:
            raise RuntimeError(f'{name}: final checkpoints must use full train/validation/test partitions.')
        if metric['checkpoint_sha256']!=sha256(ROOT/f'models/{name}.pt'):
            raise RuntimeError(f'{name}: checkpoint hash does not match its measurement record.')
    for name in names:
        required += [f'onnx/{name}.onnx',f'onnx/{name}.json',f'results/{name}_benchmark.json']
        sidecar=json.loads((ROOT/f'onnx/{name}.json').read_text())
        if sidecar['onnx_sha256']!=sha256(ROOT/f'onnx/{name}.onnx'):
            raise RuntimeError(f'{name}: ONNX hash mismatch.')
        if sidecar['checkpoint_sha256']!=sha256(ROOT/f'models/{name}.pt'):
            raise RuntimeError(f'{name}: ONNX was not exported from the submitted checkpoint.')
    if not json.loads((ROOT/'results/nas_final_verification.json').read_text())['deployable']:
        raise RuntimeError('Final NAS model violates measured deployment constraints.')
    missing=[p for p in required if not (ROOT/p).is_file()]
    if missing:raise RuntimeError('Missing required deliverables: '+', '.join(missing))
    from pypdf import PdfReader
    if not PdfReader(ROOT/'output/pdf/edge_vision_report.pdf').pages:
        raise RuntimeError('The technical report has no readable pages.')
    oversized=[p for p in required if p.endswith(('.pt','.onnx')) and (ROOT/p).stat().st_size>=100*2**20]
    if oversized:raise RuntimeError('Files exceed GitHub normal upload size; configure Git LFS before submitting: '+', '.join(oversized))
    return required


def package():
    validate()
    files={}
    for pattern in ('README.md','requirements*.txt','*.cmd','edge_lab/*.py','configs/*.json','tests/*.py','tools/*.py','docs/requirements_checklist.md'):
        for path in PROJECT.glob(pattern):files[path.relative_to(PROJECT).as_posix()]=path
    for folder in ('models','onnx','results','docs/figures','docs/screenshots','docs/samples','output/pdf'):
        for path in (ROOT/folder).rglob('*'):
            if path.is_file() and path.suffix.lower() in ('.pt','.onnx','.json','.csv','.png','.html','.pdf'):
                if path.name.startswith('nas_trial_') or path.name.endswith('_preview.pdf') or path.name=='submission_manifest.json':continue
                files[path.relative_to(ROOT).as_posix()]=path
    write_json(ROOT/'results'/'submission_manifest.json',{'created_utc':timestamp(),'files':[
        {'path':name,'bytes':path.stat().st_size,'sha256':sha256(path)} for name,path in sorted(files.items())]})
    files['results/submission_manifest.json']=ROOT/'results/submission_manifest.json'
    destination=ROOT/'submission'/'edge_vision.zip';destination.parent.mkdir(exist_ok=True)
    temporary=destination.with_suffix('.tmp')
    with zipfile.ZipFile(temporary,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=5) as archive:
        for name,path in sorted(files.items()):archive.write(path,'edge_vision/'+name)
    with zipfile.ZipFile(temporary) as archive:
        bad=archive.testzip()
        if bad:raise RuntimeError('Corrupt ZIP member: '+bad)
    temporary.replace(destination)
    print('Verified submission ZIP:',destination,flush=True)
    return destination
