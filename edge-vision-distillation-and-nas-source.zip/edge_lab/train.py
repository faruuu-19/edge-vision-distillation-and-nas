"""Independent supervised and joint hard/soft/feature KD training pipelines."""
import csv
import gc
import json
import time
from pathlib import Path
import torch
from torch import nn
from .common import ROOT, seed_all, state_hash, timestamp, write_json, sha256, replace_file
from .models import Classifier
from .losses import DistillationLoss


@torch.inference_mode()
def evaluate(model, loader, device):
    model.eval()
    loss, correct, top5, count = 0.0, 0, 0, 0
    for images, labels in loader:
        images, labels = images.to(device), labels.to(device)
        logits = model(images)
        loss += nn.functional.cross_entropy(logits, labels, reduction='sum').item()
        correct += (logits.argmax(1) == labels).sum().item()
        top5 += (logits.topk(min(5, logits.shape[1]), dim=1).indices == labels[:, None]).any(1).sum().item()
        count += len(labels)
    return {'loss': loss / count, 'top1': correct / count, 'top5': top5 / count, 'samples': count}


def load_checkpoint(path, device='cpu'):
    checkpoint = torch.load(path, map_location='cpu', weights_only=True)
    model = Classifier(checkpoint['architecture'], len(checkpoint['classes']), nas_config=checkpoint.get('nas_config'))
    model.load_state_dict(checkpoint['state_dict'], strict=True)
    return model.to(device), checkpoint


def train_model(name, architecture, data, settings, device, teacher_path=None, nas_config=None,
                train_limit=None, val_limit=None, evaluate_test=True, seed=42):
    seed_all(seed, settings.get('threads', 4))
    resolution = nas_config['resolution'] if nas_config else settings.get('resolution', 32)
    train, validation, test = data.loaders(resolution, settings['batch_size'], settings.get('workers', 0), train_limit, val_limit, settings.get('augment',True))
    # Explicitly isolated integration checks may use small subsets, never a final submission.
    if settings.get('smoke'):
        from torch.utils.data import DataLoader, Subset
        def limited(loader, count, shuffle=False):
            return DataLoader(Subset(loader.dataset, range(min(count,len(loader.dataset)))),
                batch_size=settings['batch_size'], shuffle=shuffle, num_workers=0)
        train=limited(train,64,True); validation=limited(validation,32); test=limited(test,32)
    model = Classifier(architecture, len(data.classes), settings.get('pretrained', False), nas_config).to(device)
    if device.type == 'cpu':
        model = model.to(memory_format=torch.channels_last)
    initial_hash = state_hash(model)
    teacher, distiller = None, None
    parameters = list(model.parameters())
    if teacher_path:
        if settings.get('cache_teacher',False):
            if settings.get('augment',True) or train_limit is not None or resolution!=32:
                raise ValueError('Cached teacher targets require full deterministic 32-pixel training views.')
            from .cache import CachedTargets
            from torch.utils.data import DataLoader
            cached=CachedTargets(train.dataset,ROOT/'.runs'/'teacher_targets',teacher_path)
            train=DataLoader(cached,batch_size=settings['batch_size'],shuffle=True,num_workers=0,
                generator=torch.Generator().manual_seed(data.seed))
            teacher_channels=1024
        else:
            teacher, teacher_metadata = load_checkpoint(teacher_path, device)
            teacher.eval().requires_grad_(False)
            teacher_channels=teacher.feature_channels
        distiller = DistillationLoss(model.feature_channels, teacher_channels,
            settings.get('temperature', 4.0), settings.get('alpha', 0.7), settings.get('beta', 1.0)).to(device)
        parameters += list(distiller.parameters())
    optimizer = torch.optim.SGD(parameters, lr=settings['learning_rate'], momentum=0.9, weight_decay=settings.get('weight_decay', 5e-4))
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=settings['epochs'])
    destination = ROOT / 'models' / (name + '.pt')
    destination.parent.mkdir(exist_ok=True)
    log_path = ROOT / 'results' / (name + '_history.csv')
    fields = ['epoch','train_loss','train_accuracy','hard_loss','soft_loss','feature_loss','validation_loss','validation_accuracy','seconds','learning_rate']
    history, best, start = [], -1.0, time.perf_counter()
    with log_path.open('w', newline='', encoding='utf-8') as log:
        writer = csv.DictWriter(log, fieldnames=fields)
        writer.writeheader()
        for epoch in range(1, settings['epochs'] + 1):
            model.train()
            if distiller is not None:
                distiller.train()
            totals = {'loss':0.0,'correct':0,'samples':0,'hard':0.0,'soft':0.0,'feature':0.0}
            epoch_start = time.perf_counter()
            for batch, packed in enumerate(train, 1):
                images,labels=packed[:2]
                images, labels = images.to(device), labels.to(device)
                if device.type == 'cpu':
                    images = images.contiguous(memory_format=torch.channels_last)
                optimizer.zero_grad(set_to_none=True)
                if distiller is None:
                    logits = model(images)
                    loss = nn.functional.cross_entropy(logits, labels)
                    parts = {'hard':loss.detach(),'soft':torch.tensor(0.0),'feature':torch.tensor(0.0)}
                else:
                    if teacher is None:
                        teacher_logits,teacher_features=packed[2].to(device),packed[3].to(device)
                    else:
                        with torch.no_grad():
                            teacher_features, teacher_logits = teacher.features_logits(images)
                    student_features, logits = model.features_logits(images)
                    loss, parts = distiller(logits, teacher_logits, labels, student_features, teacher_features)
                if not torch.isfinite(loss):
                    raise RuntimeError('Non-finite loss; no successful checkpoint claimed.')
                loss.backward()
                nn.utils.clip_grad_norm_(parameters, 10.0)
                optimizer.step()
                size = len(labels)
                totals['samples'] += size
                totals['loss'] += loss.item() * size
                totals['correct'] += (logits.detach().argmax(1) == labels).sum().item()
                for key in ('hard','soft','feature'):
                    totals[key] += parts[key].item() * size
                if batch == 1 or batch % 20 == 0:
                    print(json.dumps({'run':name,'epoch':epoch,'batch':batch,'batches':len(train),
                        'loss':totals['loss']/totals['samples'],'accuracy':totals['correct']/totals['samples']}), flush=True)
            measured = evaluate(model, validation, device)
            row = {'epoch':epoch,'train_loss':totals['loss']/totals['samples'],
                'train_accuracy':totals['correct']/totals['samples'],
                **{key+'_loss':totals[key]/totals['samples'] for key in ('hard','soft','feature')},
                'validation_loss':measured['loss'],'validation_accuracy':measured['top1'],
                'seconds':time.perf_counter()-epoch_start,'learning_rate':optimizer.param_groups[0]['lr']}
            writer.writerow(row)
            log.flush()
            history.append(row)
            print(json.dumps({'run':name,**row}), flush=True)
            if measured['top1'] > best:
                best = measured['top1']
                record = {'format_version':1,'name':name,'architecture':architecture,'nas_config':nas_config,
                    **data.metadata(resolution), 'state_dict':{key:value.detach().cpu() for key,value in model.state_dict().items()},
                    'epoch':epoch,'settings':settings,'seed':seed,'initial_state_sha256':initial_hash,
                    'training_samples':len(train.dataset),'validation_samples':len(validation.dataset),
                    'validation':measured,'teacher_checkpoint_sha256':sha256(teacher_path) if teacher_path else None,
                    'training_kind':'distillation' if distiller is not None else 'supervised','created_utc':timestamp()}
                if distiller is not None:
                    record['feature_projector_state'] = {k:v.detach().cpu() for k,v in distiller.state_dict().items()}
                temporary = destination.with_suffix('.tmp')
                torch.save(record, temporary)
                replace_file(temporary,destination)
            scheduler.step()
    best_model, checkpoint = load_checkpoint(destination, device)
    result = {'name':name,'architecture':architecture,'kind':checkpoint['training_kind'],'dataset':data.name,
        'epochs':settings['epochs'],'best_epoch':checkpoint['epoch'],'training_samples':len(train.dataset),
        'validation_samples':len(validation.dataset),'validation':checkpoint['validation'],
        'test':evaluate(best_model, test, device) if evaluate_test else None,
        'training_seconds':time.perf_counter()-start,'parameter_count':sum(p.numel() for p in best_model.parameters()),
        'checkpoint':str(destination.relative_to(ROOT)),'checkpoint_bytes':destination.stat().st_size,
        'checkpoint_sha256':sha256(destination),'initial_state_sha256':initial_hash,'settings':settings,'created_utc':timestamp()}
    write_json(ROOT/'results'/(name+'_metrics.json'),result)
    del model, best_model, teacher, distiller, optimizer
    gc.collect()
    if device.type == 'cuda':
        torch.cuda.empty_cache()
    elif device.type == 'xpu':
        torch.xpu.empty_cache()
    return result
