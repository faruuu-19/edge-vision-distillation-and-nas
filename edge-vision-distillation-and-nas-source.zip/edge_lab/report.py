"""Build the technical report exclusively from recorded experiment artifacts."""
import csv
import html
import json
import os
import shutil
import subprocess
from pathlib import Path
from .common import ROOT, timestamp, write_json


def read(name):
    return json.loads((ROOT/'results'/name).read_text(encoding='utf-8'))


def capture_results(rows, hardware):
    """Capture an actual local results page in a separate headless browser profile."""
    directory=ROOT/'docs'/'screenshots';directory.mkdir(parents=True,exist_ok=True)
    headers=['Model','Test accuracy','CPU p95 (ms)','ONNX MiB','Peak process MiB']
    table=''.join('<tr>'+''.join('<td>'+html.escape(str(cell))+'</td>' for cell in [r['model'],
        f"{100*r['test_accuracy']:.2f}%",f"{r['latency_p95_ms']:.3f}",f"{r['model_bytes']/2**20:.2f}",
        'unsupported' if r['peak_memory_bytes'] is None else f"{r['peak_memory_bytes']/2**20:.1f}"])+'</tr>' for r in rows)
    source=directory/'results.html'
    source.write_text('<!doctype html><meta charset="utf-8"><title>Recorded Edge experiment</title>'
        '<style>body{font:20px Arial;background:#f3f5f9;color:#172b45;padding:36px}table{border-collapse:collapse;background:white;width:100%}'
        'th,td{padding:15px;border-bottom:1px solid #ccd5df;text-align:left}h1{color:#145b70}pre{white-space:pre-wrap;font-size:16px}</style>'
        '<h1>Assignment 04 - Recorded results</h1><p>edge_vision | Section A | '+html.escape(timestamp())+'</p>'
        '<table><tr>'+''.join('<th>'+h+'</th>' for h in headers)+'</tr>'+table+'</table>'
        '<h2>Benchmark hardware</h2><pre>'+html.escape(json.dumps(hardware,indent=2))+'</pre>',encoding='utf-8')
    browsers=[os.environ.get('EDGE_BROWSER',''),r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe',
        r'C:\Program Files\Google\Chrome\Application\chrome.exe',shutil.which('chromium'),shutil.which('google-chrome')]
    browser=next((str(p) for p in browsers if p and Path(p).is_file()),None)
    if browser is None:
        raise RuntimeError('A Chromium browser is needed for the report screenshot. Set EDGE_BROWSER to its executable and rerun report.')
    shot=directory/'recorded_results.png'
    profile=ROOT/'.runs'/'report_browser';profile.mkdir(parents=True,exist_ok=True)
    subprocess.run([browser,'--headless','--disable-gpu','--no-first-run','--hide-scrollbars',
        '--user-data-dir='+str(profile),'--window-size=1500,1200','--screenshot='+str(shot),source.as_uri()],
        check=True,capture_output=True,timeout=60,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    if not shot.is_file():raise RuntimeError('Browser did not produce the required screenshot.')
    inference_source=directory/'inference.html'
    examples=read('inference_examples.json')
    body=''
    for example in examples:
        body+='<section><h3>'+html.escape(example['model'])+'</h3><p>True label: '+html.escape(example['true_label'])+'</p><table><tr><th>Backend</th><th>Top-1 class</th><th>Probability</th></tr>'
        for key in ('torch_top5','onnx_top5'):
            best=example[key][0]
            body+='<tr><td>'+key+'</td><td>'+html.escape(best['class'])+'</td><td>'+f"{best['probability']:.6f}"+'</td></tr>'
        body+='</table></section>'
    inference_source.write_text('<!doctype html><meta charset="utf-8"><style>body{font:22px Arial;padding:25px;background:#f3f5f9}.cards{display:grid;grid-template-columns:1fr 1fr;gap:20px}section{background:white;padding:12px}h3{margin:0 0 4px;font-size:24px}p{margin:5px}td,th{padding:5px 15px;text-align:left}h1{font-size:30px}</style><h1>Unified inference - actual held-out images</h1><div class="cards">'+body+'</div>',encoding='utf-8')
    inference=directory/'inference.png'
    subprocess.run([browser,'--headless','--disable-gpu','--no-first-run','--hide-scrollbars',
        '--user-data-dir='+str(profile),'--window-size=1400,1000','--screenshot='+str(inference),inference_source.as_uri()],
        check=True,capture_output=True,timeout=60,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    return shot,inference


def make_plots(rows):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    directory=ROOT/'docs'/'figures';directory.mkdir(parents=True,exist_ok=True)
    fig, axes=plt.subplots(1,2,figsize=(11,4.2),layout='constrained')
    labels=['MobileNetV2','SqueezeNet','EfficientNet-Lite0']
    import numpy as np
    x=np.arange(3)
    for mode,offset,color in [('baseline',-.18,'#587a9b'),('kd',.18,'#159a94')]:
        selected=[r for r in rows if r['model'].endswith('_'+mode)]
        axes[0].bar(x+offset,[100*r['test_accuracy'] for r in selected],width=.35,label=mode,color=color)
    axes[0].set(xticks=x,xticklabels=labels,ylabel='CIFAR-100 test accuracy (%)',title='Independent baseline vs distillation')
    axes[0].tick_params(axis='x',labelrotation=15);axes[0].legend()
    for r in rows:
        axes[1].scatter(r['model_bytes']/2**20,r['latency_p95_ms'])
        axes[1].annotate(r['model'].replace('efficientnet_lite0','Lite0').replace('mobilenet_v2','Mobile'),
            (r['model_bytes']/2**20,r['latency_p95_ms']),fontsize=7,xytext=(3,4),textcoords='offset points')
    axes[1].set(xlabel='ONNX storage (MiB)',ylabel='CPU p95 latency (ms)',title='Measured deployment cost')
    plot=directory/'comparison.png';fig.savefig(plot,dpi=170);plt.close(fig)
    fig,axis=plt.subplots(figsize=(10,4),layout='constrained')
    for r in rows:
        with (ROOT/'results'/(r['model']+'_history.csv')).open(newline='') as stream:
            history=list(csv.DictReader(stream))
        axis.plot([int(h['epoch']) for h in history],[100*float(h['validation_accuracy']) for h in history],label=r['model'],marker='o',markersize=3)
    axis.set(xlabel='Epoch',ylabel='Validation accuracy (%)',title='Recorded learning curves')
    axis.legend(fontsize=7,ncol=2);curves=directory/'learning_curves.png';fig.savefig(curves,dpi=170);plt.close(fig)
    return plot,curves


def build_report():
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.lib.units import inch
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak
    manifest=read('run_manifest.json')
    if manifest['status']!='training_complete':raise RuntimeError('Finish the training pipeline before creating its final report.')
    smoke=bool(manifest['configuration'].get('smoke'))
    rows=read('benchmarks.json');hardware=read('hardware.json');teacher=read('teacher_metrics.json')
    best=read('best_architecture.json');verification=read('nas_final_verification.json')
    screenshot,inference_shot=capture_results(rows,hardware);comparison,curves=make_plots(rows)
    destination=ROOT/'output'/'pdf'/('edge_vision_preview.pdf' if smoke else 'edge_vision_report.pdf')
    destination.parent.mkdir(parents=True,exist_ok=True)
    styles=getSampleStyleSheet();story=[]
    styles['BodyText'].fontSize=9.5;styles['BodyText'].leading=12
    styles['BodyText'].spaceBefore=0;styles['BodyText'].allowWidows=0;styles['BodyText'].allowOrphans=0
    def p(text,style='BodyText'):
        story.append(Paragraph(text,styles[style]));story.append(Spacer(1,6))
    def table(values,widths=None):
        converted=[[Paragraph(html.escape(str(v)),styles['BodyText']) for v in row] for row in values]
        t=Table(converted,colWidths=widths,repeatRows=1,hAlign='LEFT')
        t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#dceaf1')),('VALIGN',(0,0),(-1,-1),'TOP'),
            ('LINEBELOW',(0,0),(-1,-1),.4,colors.lightgrey),('LEFTPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),7)]))
        story.append(t);story.append(Spacer(1,12))
    p('Edge Computing &amp; Intelligent Systems','Title');p('Assignment 04 | edge_vision | Section A','Heading2')
    if smoke:p('INTEGRATION CHECK ONLY - tiny data subsets, unrepresentative accuracy, not a submission.','Heading2')
    p('Knowledge distillation and hardware-aware neural architecture search','Heading1')
    p('This report is generated from saved measurements, checkpoints and experiment metadata. All accuracy values are observed, with no guarantee that KD improves each baseline. Generated UTC: '+html.escape(timestamp()))
    p('Experimental setup','Heading2')
    table([['Item','Recorded value'],['Training hardware',hardware.get('accelerator') or hardware['cpu']],['OS / training device',hardware['os']+' / '+hardware['training_device']],
        ['PyTorch / ONNX Runtime',hardware['torch']+' / '+hardware['versions']['onnxruntime']],['CPU benchmark',hardware['cpu']],
        ['Memory scope','Whole isolated inference process peak working set (Windows); includes runtime and model, not tensor-only allocation.'],
        ['Protocol','Batch 1; CPUExecutionProvider; 10 warm-ups; 50 timed runs; '+str(rows[0]['threads'])+' intra-op / 1 inter-op threads. NAS search uses configured repeat count.']], [120,390])
    configuration=manifest['configuration']
    table([['Schedule','Teacher','Students'],['Epochs',configuration['teacher']['epochs'],configuration['student']['epochs']],
        ['Batch size',configuration['teacher']['batch_size'],configuration['student']['batch_size']],
        ['SGD learning rate',configuration['teacher']['learning_rate'],configuration['student']['learning_rate']],
        ['KD coefficients','Not applicable','T='+str(configuration['student']['temperature'])+', alpha='+str(configuration['student']['alpha'])+', beta='+str(configuration['student']['beta'])]], [130,150,230])
    p('Optimizer: SGD momentum 0.9, weight decay 0.0005 unless overridden in the recorded settings; cosine annealing. Best checkpoints are selected by validation top-1, with official test evaluation afterward. The configuration and per-epoch logs are included.')
    p('Data and reproducibility','Heading2')
    p('CIFAR-100 is used for Q1 and CIFAR-10 for Q2. Each official 50,000-image training split is stratified into 45,000 training and 5,000 validation images (seed 42). Normalization is computed from the training partition only. The official 10,000-image test split is evaluated only after model selection; it never selects a NAS candidate. Smoke checks use explicitly limited subsets and cannot be packaged.')
    story.append(PageBreak());p('Teacher and knowledge distillation','Heading1')
    initialization='torchvision ImageNet weights' if configuration['teacher'].get('pretrained') else 'random initialization'
    p('The ResNet-50 teacher starts from '+initialization+' and is trained on CIFAR-100, including its replacement 100-class head. The original 7x7 stem and pooling remain; inputs are 32x32. Teacher intermediate features come from layer3 (1024 channels). Student features come from their final convolutional maps. The EfficientNet model is timm tf_efficientnet_lite0, not EfficientNet-B0.')
    p('The joint objective is L = (1-alpha) CE(y, student) + alpha T^2 KL(softmax(teacher/T) || softmax(student/T)) + beta MSE(normalize(project(student features)), normalize(teacher features)). A learned 1x1 projection matches feature channels and adaptive pooling matches spatial size. Teacher parameters and targets are detached; the student and feature projector receive gradients.')
    p('Each baseline is initialized independently of the teacher and receives only hard-label cross entropy. Matched baseline/KD seeds, augmentation, optimizer and epoch budget permit comparison. KD adds teacher guidance and a training-only projector. Neither is required for inference. CPU cached-target mode explicitly disables augmentation for both runs; the Intel GPU profile uses online targets and augmentation.')
    p('Teacher result: test top-1 '+f"{100*teacher['test']['top1']:.2f}%"+'; epochs '+str(teacher['epochs'])+'; training images '+str(teacher['training_samples'])+'.')
    p('Student experimental results','Heading2')
    table([['Student','Baseline test %','KD test %','KD change (pp)']]+[[a,
        f"{100*rows[2*i]['test_accuracy']:.2f}",f"{100*rows[2*i+1]['test_accuracy']:.2f}",
        f"{100*(rows[2*i+1]['test_accuracy']-rows[2*i]['test_accuracy']):+.2f}"] for i,a in enumerate(['MobileNetV2','SqueezeNet','EfficientNet-Lite0'])],[165,110,110,125])
    story.append(Image(str(comparison),width=510,height=195));story.append(Spacer(1,10))
    story.append(PageBreak());p('Learning curves and architecture search','Heading1')
    story.append(Image(str(curves),width=510,height=204))
    p('Hardware-aware NAS','Heading1')
    p('Optuna TPE maximizes CIFAR-10 validation accuracy after three startup trials. The space varies depth (2-5), channels (16,24,32,48,64,96,128), kernel (3,5,7), standard or depthwise-separable convolution, activation (ReLU/ReLU6/SiLU/HardSwish), and input resolution (16/24/32). Each candidate is generated from its saved configuration.')
    p('The exported candidate is measured in an isolated ONNX Runtime CPU process before training. Candidates exceeding any supported resource constraint are rejected. Peak-memory availability is recorded; unsupported memory is not replaced by zero. Parameter count is never substituted for measured latency. Constraints were fixed in the configuration before search: '+html.escape(json.dumps(best['constraints']))+'.')
    history=read('nas_search_history.json')
    p('Completed candidates: '+str(sum(r['status']=='completed' for r in history))+'; rejected: '+str(sum(r['status']=='rejected' for r in history))+'. Selected trial: '+str(best['selected_trial'])+'; selection validation top-1: '+f"{100*best['selection_validation_accuracy']:.2f}%"+'.')
    p('Selected architecture','Heading2')
    table([['Resolution','Block','Channels','Kernel','Operation','Activation']]+[[best['configuration']['resolution'],i,b['channels'],b['kernel'],b['operation'],b['activation']] for i,b in enumerate(best['configuration']['blocks'],1)],[65,40,65,50,150,140])
    p('The final model is initialized and trained from scratch with a fresh optimizer and seed. Saved initial-state hashes distinguish it from the search trial. Its final CPU resource measurements are checked again. Final deployment constraint violations: '+html.escape(str(verification['constraint_violations']))+'. The search CPU is this machine; results do not establish latency on every edge device.')
    story.append(PageBreak());p('Deployment and benchmarking','Heading1')
    p('All six student variants and the final NAS model are exported as fixed batch-1 ONNX graphs, opset 18, without teacher or feature projector. The ONNX checker and three deterministic random-input comparisons against PyTorch must pass (rtol 0.001, atol 0.0001). Sidecars retain class labels, normalization, input resolution, checkpoint hashes and parity evidence. The same inference command accepts all architectures using their metadata.')
    table([['Model','Test %','p95 ms','ONNX MiB','Peak MiB']]+[[r['model'],f"{100*r['test_accuracy']:.2f}",f"{r['latency_p95_ms']:.3f}",f"{r['model_bytes']/2**20:.2f}",
        'N/A' if r['peak_memory_bytes'] is None else f"{r['peak_memory_bytes']/2**20:.1f}"] for r in rows],[190,65,75,85,95])
    p('Latency excludes preprocessing and session construction. The JSON records raw timing samples and process memory scope. Storage is the actual ONNX file size. Memory includes Python/NumPy/ORT overhead and cannot be interpreted as model tensors alone. CPU contention, thermal throttling, power mode and operating system can change timing. A short epoch schedule is a resource-budget experiment; one seed does not establish statistical significance.')
    p('Execution evidence','Heading1')
    p('The following is a real headless browser screenshot of the generated results page, populated only from the saved benchmark CSV/JSON. The original screenshot and HTML are included for inspection.')
    story.append(Image(str(screenshot),width=410,height=328));story.append(Spacer(1,12))
    story.append(PageBreak());p('Unified inference evidence','Heading1')
    p('Actual PyTorch and ONNX predictions for the same held-out images. These examples illustrate executable inference and can be incorrect; they are not used to tune or select models. Full top-5 predictions and image labels are saved in results/inference_examples.json.')
    story.append(Image(str(inference_shot),width=510,height=364));story.append(Spacer(1,12))
    p('Reproduction and submission','Heading2')
    p('Follow README.md: SETUP_INTEL.cmd, RUN_INTEL.cmd, then inspect the PDF and run VERIFY_SUBMISSION.cmd. The pipeline records its configuration, package versions, seeds and stage status. Re-running the same configuration with --resume skips completed stages and continues the NAS study. Save model/results changes to GitHub using the README commands. Upload submission/edge_vision.zip to Google Classroom and prepare to explain each component in the viva.')
    p('References','Heading2')
    for ref in ['Hinton et al., Distilling the Knowledge in a Neural Network, arXiv:1503.02531.',
        'PyTorch Intel GPU guide: https://docs.pytorch.org/docs/stable/notes/get_start_xpu.html',
        'timm EfficientNet-Lite: https://huggingface.co/docs/timm/en/models/tf-efficientnet-lite',
        'Optuna TPE: https://optuna.readthedocs.io/en/stable/reference/samplers/generated/optuna.samplers.TPESampler.html',
        'CIFAR datasets: https://www.cs.toronto.edu/~kriz/cifar.html']:
        p(html.escape(ref))
    def footer(canvas,document):
        canvas.setFont('Helvetica',8);canvas.setFillColor(colors.grey)
        canvas.drawString(42,25,'edge_vision | Assignment 04'+(' | SMOKE PREVIEW' if smoke else ''))
        canvas.drawRightString(A4[0]-42,25,str(document.page))
    SimpleDocTemplate(str(destination),pagesize=A4,rightMargin=42,leftMargin=42,topMargin=40,bottomMargin=42,
        title='Assignment 04 - edge_vision A',author='edge_vision').build(story,onFirstPage=footer,onLaterPages=footer)
    write_json(ROOT/'results'/'report.json',{'path':str(destination.relative_to(ROOT)),'smoke':smoke,'created_utc':timestamp()})
    print('Report:',destination,flush=True)
    return destination
