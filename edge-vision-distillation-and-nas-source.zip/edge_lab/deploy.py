import json
import subprocess
import sys
from pathlib import Path
import numpy as np
import torch
from .common import ROOT, PROJECT, sha256, timestamp, write_json
from .train import load_checkpoint


def export_model(model, resolution, path):
    import onnx
    import onnxruntime as ort
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    model=model.to('cpu').eval()
    example=torch.randn(1,3,resolution,resolution)
    torch.onnx.export(model,(example,),str(path),dynamo=True,external_data=False,
        input_names=['images'],output_names=['logits'],opset_version=18,verbose=False)
    onnx.checker.check_model(onnx.load(str(path)))
    options=ort.SessionOptions();options.intra_op_num_threads=4;options.inter_op_num_threads=1
    session=ort.InferenceSession(str(path),sess_options=options,providers=['CPUExecutionProvider'])
    errors=[]
    for seed in (11,22,33):
        x=torch.randn(example.shape,generator=torch.Generator().manual_seed(seed))
        with torch.inference_mode():expected=model(x).numpy()
        actual=session.run(None,{'images':x.numpy()})[0]
        np.testing.assert_allclose(actual,expected,rtol=1e-3,atol=1e-4)
        errors.append(float(np.max(np.abs(actual-expected))))
    return {'onnx_bytes':path.stat().st_size,'onnx_sha256':sha256(path),
        'parity_max_absolute_error':max(errors),'parity_samples':3,'opset':18,'exporter':'torch.export/dynamo',
        'input_shape':[1,3,resolution,resolution],'output_classes':int(actual.shape[1])}


def measure_model(path,resolution,threads=4,repeats=50):
    run=subprocess.run([sys.executable,'-m','edge_lab.ort_worker',str(path),'--resolution',str(resolution),
        '--threads',str(threads),'--repeats',str(repeats)],cwd=PROJECT,text=True,capture_output=True,check=True,
        creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    result=json.loads(run.stdout.strip().splitlines()[-1])
    result['model_bytes']=Path(path).stat().st_size
    result['measured_utc']=timestamp()
    return result


def export_checkpoint(checkpoint_path,threads=4,repeats=50):
    model,metadata=load_checkpoint(checkpoint_path)
    name=metadata['name'];destination=ROOT/'onnx'/(name+'.onnx')
    exported=export_model(model,metadata['resolution'],destination)
    sidecar={key:value for key,value in metadata.items() if key not in ('state_dict','feature_projector_state')}
    sidecar.update(exported)
    sidecar['checkpoint_sha256']=sha256(checkpoint_path)
    write_json(destination.with_suffix('.json'),sidecar)
    measured=measure_model(destination,metadata['resolution'],threads,repeats)
    record={'name':name,'architecture':metadata['architecture'],'training_kind':metadata['training_kind'],**exported,**measured}
    write_json(ROOT/'results'/(name+'_benchmark.json'),record)
    return record


def predict(path,image_path,onnx=False,topk=5):
    from PIL import Image
    if onnx:
        import onnxruntime as ort
        metadata=json.loads(Path(path).with_suffix('.json').read_text())
        options=ort.SessionOptions();options.intra_op_num_threads=4
        session=ort.InferenceSession(str(path),sess_options=options,providers=['CPUExecutionProvider'])
    else:
        model,metadata=load_checkpoint(path)
        model.eval()
    size=metadata['resolution']
    image=Image.open(image_path).convert('RGB').resize((size,size),Image.Resampling.BILINEAR)
    array=np.array(image,dtype=np.float32)/255
    array=(array-np.array(metadata['mean'],dtype=np.float32))/np.array(metadata['std'],dtype=np.float32)
    array=np.ascontiguousarray(array.transpose(2,0,1)[None])
    if onnx:
        logits=session.run(None,{session.get_inputs()[0].name:array})[0][0]
    else:
        with torch.inference_mode():logits=model(torch.from_numpy(array)).numpy()[0]
    probabilities=np.exp(logits-logits.max());probabilities/=probabilities.sum()
    indices=np.argsort(probabilities)[::-1][:topk]
    return [{'class':metadata['classes'][int(i)],'probability':float(probabilities[i])} for i in indices]
