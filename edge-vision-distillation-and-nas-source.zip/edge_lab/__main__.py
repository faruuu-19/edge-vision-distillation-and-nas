import argparse
import json
import os
import sys
from pathlib import Path


def main():
    for stream in (sys.stdout,sys.stderr):
        if hasattr(stream,'reconfigure'):stream.reconfigure(encoding='utf-8',errors='replace')
    parser=argparse.ArgumentParser(description='Edge Computing Assignment 04: KD, hardware-aware NAS and ONNX deployment')
    parser.add_argument('--output-root',type=Path,help='Independent experiment directory; avoids mixing CPU and GPU runs.')
    sub=parser.add_subparsers(dest='command',required=True)
    all_run=sub.add_parser('run-all');all_run.add_argument('--config',type=Path,default=Path('configs/gpu.json'))
    all_run.add_argument('--resume',action='store_true');all_run.add_argument('--require-accelerator',action='store_true')
    preflight=sub.add_parser('preflight');preflight.add_argument('--require-xpu',action='store_true')
    sub.add_parser('summarize');sub.add_parser('report');sub.add_parser('package')
    infer=sub.add_parser('infer');infer.add_argument('--model',type=Path,required=True);infer.add_argument('--image',type=Path,required=True)
    infer.add_argument('--backend',choices=['torch','onnx'],default='onnx');infer.add_argument('--topk',type=int,default=5)
    export=sub.add_parser('export');export.add_argument('--checkpoint',type=Path,required=True)
    args=parser.parse_args()
    if args.output_root:os.environ['EDGE_RUN_DIR']=str(args.output_root.resolve())
    if args.command=='run-all':
        from .pipeline import run_all
        run_all(args.config,args.resume,args.require_accelerator)
    elif args.command=='preflight':
        from .preflight import check
        check(args.require_xpu)
    elif args.command=='infer':
        from .deploy import predict
        print(json.dumps(predict(args.model,args.image,args.backend=='onnx',args.topk),indent=2))
    elif args.command=='export':
        from .deploy import export_checkpoint
        print(json.dumps(export_checkpoint(args.checkpoint),indent=2))
    elif args.command=='summarize':
        from .pipeline import summarize
        summarize()
    elif args.command=='report':
        from .report import build_report
        build_report()
    else:
        from .submission import package
        package()


if __name__=='__main__':main()
