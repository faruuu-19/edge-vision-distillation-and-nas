import json
from pathlib import Path
import numpy as np
import torch
from PIL import Image
from torch.utils.data import Dataset, DataLoader
from torchvision import datasets, transforms
from .common import ROOT, PROJECT, write_json


class ImageView(Dataset):
    def __init__(self, base, indices, transform):
        self.base, self.indices, self.transform = base, list(map(int, indices)), transform

    def __len__(self):
        return len(self.indices)

    def __getitem__(self, position):
        index = self.indices[position]
        return self.transform(Image.fromarray(self.base.data[index])), int(self.base.targets[index])


class CIFARData:
    def __init__(self, name, seed=42, data_root=None):
        if name not in ('cifar10', 'cifar100'):
            raise ValueError('Unsupported dataset.')
        self.name, self.seed = name, seed
        dataset = datasets.CIFAR100 if name == 'cifar100' else datasets.CIFAR10
        # The official TensorFlow mirror serves the original, MD5-checked CIFAR archives.
        dataset.url = 'https://storage.googleapis.com/tensorflow/tf-keras-datasets/' + dataset.filename
        root = Path(data_root or PROJECT / '.data')
        self.training = dataset(root, train=True, download=True)
        self.test = dataset(root, train=False, download=True)
        self.classes = self.training.classes
        rng, training, validation = np.random.default_rng(seed), [], []
        labels = np.array(self.training.targets)
        for label in range(len(self.classes)):
            indices = np.flatnonzero(labels == label)
            rng.shuffle(indices)
            boundary = len(indices) // 10
            validation.extend(indices[:boundary])
            training.extend(indices[boundary:])
        rng.shuffle(training)
        rng.shuffle(validation)
        self.train_indices, self.val_indices = training, validation
        # Compute normalization from the training partition only, without a large float copy.
        total, squared, pixels = np.zeros(3), np.zeros(3), 0
        for start in range(0, len(training), 512):
            block = self.training.data[np.array(training[start:start + 512])].astype(np.float64) / 255
            total += block.sum(axis=(0, 1, 2))
            squared += (block * block).sum(axis=(0, 1, 2))
            pixels += np.prod(block.shape[:3])
        self.mean = (total / pixels).tolist()
        self.std = np.sqrt(squared / pixels - (total / pixels) ** 2).tolist()
        write_json(ROOT / 'results' / f'{name}_split.json', {
            'seed': seed, 'train_indices': list(map(int, training)), 'validation_indices': list(map(int, validation)),
            'test_count': len(self.test), 'normalization': {'mean': self.mean, 'std': self.std},
            'note': 'Validation is stratified from the training set; official test data is never used for search selection.'})

    def loaders(self, resolution=32, batch_size=64, workers=0, train_limit=None, val_limit=None, augment=True):
        train_transform = transforms.Compose(([
            transforms.RandomCrop(32, padding=4), transforms.RandomHorizontalFlip()] if augment else []) + [
            transforms.Resize((resolution, resolution)), transforms.ToTensor(), transforms.Normalize(self.mean, self.std)])
        evaluation_transform = transforms.Compose([
            transforms.Resize((resolution, resolution)), transforms.ToTensor(), transforms.Normalize(self.mean, self.std)])
        train = ImageView(self.training, self.train_indices[:train_limit], train_transform)
        validation = ImageView(self.training, self.val_indices[:val_limit], evaluation_transform)
        test = ImageView(self.test, range(len(self.test)), evaluation_transform)
        generator = torch.Generator().manual_seed(self.seed)
        options = {'batch_size': batch_size, 'num_workers': workers, 'pin_memory': torch.cuda.is_available()}
        return (DataLoader(train, shuffle=True, generator=generator, **options),
                DataLoader(validation, shuffle=False, **options), DataLoader(test, shuffle=False, **options))

    def metadata(self, resolution):
        return {'dataset': self.name, 'classes': self.classes, 'resolution': resolution,
                'mean': self.mean, 'std': self.std, 'split_seed': self.seed}
