"""Optuna TPE search with hard constraints from actual isolated CPU measurements."""
import csv
import json
from pathlib import Path
import optuna
from .common import ROOT, seed_all, write_json, timestamp
from .models import Classifier, sample_architecture
from .deploy import export_model, measure_model, export_checkpoint
from .train import train_model


def constraint_violations(measurement, constraints):
    failed=[]
    if measurement['latency_p95_ms']>constraints['max_latency_p95_ms']:
        failed.append('latency')
    if measurement['model_bytes']>constraints['max_model_bytes']:
        failed.append('storage')
    memory=measurement.get('peak_memory_bytes')
    if memory is not None and memory>constraints['max_peak_memory_bytes']:
        failed.append('process_peak_memory')
    return failed


def search(data, configuration, device):
    settings=configuration['nas'];seed=configuration['seed'];threads=configuration['threads']
    scratch=ROOT/'.runs'/'nas';scratch.mkdir(parents=True,exist_ok=True)
    history_path=ROOT/'results'/'nas_search_history.json'
    history=json.loads(history_path.read_text()) if history_path.exists() else []
    def objective(trial):
        architecture=sample_architecture(trial)
        seed_all(seed+trial.number,threads)
        candidate=Classifier('nas',10,nas_config=architecture)
        path=scratch/f'trial_{trial.number}.onnx'
        export_model(candidate,architecture['resolution'],path)
        measured=measure_model(path,architecture['resolution'],threads,settings.get('benchmark_repeats',30))
        failures=constraint_violations(measured,settings['constraints'])
        record={'trial':trial.number,'configuration':architecture,'measurement':measured,
            'constraint_violations':failures,'memory_constraint_supported':measured['peak_memory_bytes'] is not None,
            'status':'rejected' if failures else 'training','validation_accuracy':None}
        trial.set_user_attr('architecture',architecture)
        trial.set_user_attr('measurement',measured)
        if failures:
            history.append(record);write_json(ROOT/'results'/'nas_search_history.json',history)
            raise optuna.TrialPruned('Measured deployment constraint violated: '+', '.join(failures))
        training={**configuration['student'],'epochs':settings['candidate_epochs'],'threads':threads,
            'resolution':architecture['resolution'],'pretrained':False,'cache_teacher':False,'augment':True}
        outcome=train_model(f'nas_trial_{trial.number}','nas',data,training,device,nas_config=architecture,
            train_limit=settings['candidate_train_samples'],val_limit=settings['candidate_validation_samples'],
            evaluate_test=False,seed=seed+trial.number)
        record.update(status='completed',validation_accuracy=outcome['validation']['top1'],
            candidate_training_seconds=outcome['training_seconds'],initial_state_sha256=outcome['initial_state_sha256'])
        history.append(record);write_json(ROOT/'results'/'nas_search_history.json',history)
        return outcome['validation']['top1']
    study=optuna.create_study(direction='maximize',sampler=optuna.samplers.TPESampler(seed=seed,n_startup_trials=3),
        study_name='edge_hardware_nas',storage='sqlite:///'+str(scratch/'study.sqlite3'),load_if_exists=True)
    # A terminated process cannot leave RUNNING trials counted as completed search work.
    for previous in study.get_trials(states=(optuna.trial.TrialState.RUNNING,)):
        study.tell(previous.number,state=optuna.trial.TrialState.FAIL)
    finished=sum(t.state in (optuna.trial.TrialState.COMPLETE,optuna.trial.TrialState.PRUNED) for t in study.trials)
    study.optimize(objective,n_trials=max(0,settings['trials']-finished),gc_after_trial=True)
    completed=[t for t in study.trials if t.state==optuna.trial.TrialState.COMPLETE]
    if not completed:
        raise RuntimeError('No measured architecture met the predefined constraints; no best model is claimed.')
    best=study.best_trial
    architecture=best.user_attrs['architecture']
    write_json(ROOT/'results'/'best_architecture.json',{'configuration':architecture,'selected_trial':best.number,
        'selection_validation_accuracy':best.value,'search_measurement':best.user_attrs['measurement'],
        'constraints':settings['constraints'],'created_utc':timestamp(),
        'selection_uses_official_test_set':False})
    fields=['trial','status','validation_accuracy','latency_mean_ms','latency_p95_ms','model_bytes','peak_memory_bytes','violations','configuration']
    with (ROOT/'results'/'nas_search_history.csv').open('w',newline='',encoding='utf-8') as stream:
        writer=csv.DictWriter(stream,fieldnames=fields);writer.writeheader()
        for row in history:
            writer.writerow({'trial':row['trial'],'status':row['status'],'validation_accuracy':row['validation_accuracy'],
                **{key:row['measurement'].get(key) for key in fields if key in row['measurement']},
                'violations':','.join(row['constraint_violations']),'configuration':json.dumps(row['configuration'])})
    # Fresh initialization and optimizer, not a continued trial checkpoint.
    final_settings={**configuration['student'],'epochs':settings['final_epochs'],'threads':threads,
        'pretrained':False,'cache_teacher':False,'augment':True}
    result=train_model('nas_best','nas',data,final_settings,device,nas_config=architecture,seed=seed+10000)
    selected=next(row for row in history if row['trial']==best.number)
    assert result['initial_state_sha256']!=selected['initial_state_sha256']
    measured=export_checkpoint(ROOT/'models'/'nas_best.pt',threads)
    final_failures=constraint_violations(measured,settings['constraints'])
    write_json(ROOT/'results'/'nas_final_verification.json',{'trained_from_scratch':True,
        'final_measurement':measured,'constraint_violations':final_failures,
        'deployable':not final_failures,'note':'Fresh final model is remeasured; deployment constraints are not inferred from parameter count.'})
    if final_failures:
        raise RuntimeError('Refitted architecture violates final measured constraints; see the actual verification record.')
    return result
