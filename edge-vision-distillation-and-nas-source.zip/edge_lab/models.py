"""Named architecture adapters and an independently configurable NAS CNN."""
import torch
from torch import nn
from torch.nn import functional as F

STUDENTS = ('mobilenet_v2', 'squeezenet', 'efficientnet_lite0')


class Classifier(nn.Module):
    def __init__(self, architecture, classes, pretrained=False, nas_config=None):
        super().__init__()
        self.architecture = architecture
        if architecture == 'resnet50':
            from torchvision.models import resnet50, ResNet50_Weights
            self.network = resnet50(weights=ResNet50_Weights.DEFAULT if pretrained else None)
            self.network.fc = nn.Linear(self.network.fc.in_features, classes)
            self.feature_channels = 1024  # layer3, before the final residual stage
        elif architecture == 'mobilenet_v2':
            from torchvision.models import mobilenet_v2
            self.network = mobilenet_v2(weights=None, num_classes=classes)
            self.feature_channels = 1280
        elif architecture == 'squeezenet':
            from torchvision.models import squeezenet1_1
            self.network = squeezenet1_1(weights=None, num_classes=classes)
            self.feature_channels = 512
        elif architecture == 'efficientnet_lite0':
            import timm
            self.network = timm.create_model('tf_efficientnet_lite0', pretrained=False, num_classes=classes)
            self.feature_channels = self.network.num_features
        elif architecture == 'nas':
            if nas_config is None:
                raise ValueError('A NAS architecture configuration is required.')
            self.network = SearchCNN(nas_config, classes)
            self.feature_channels = nas_config['blocks'][-1]['channels']
        else:
            raise ValueError('Unknown architecture: ' + architecture)

    def features_logits(self, images):
        net = self.network
        if self.architecture == 'resnet50':
            hidden = net.maxpool(net.relu(net.bn1(net.conv1(images))))
            hidden = net.layer2(net.layer1(hidden))
            features = net.layer3(hidden)
            logits = net.fc(torch.flatten(net.avgpool(net.layer4(features)), 1))
        elif self.architecture == 'mobilenet_v2':
            features = net.features(images)
            logits = net.classifier(F.adaptive_avg_pool2d(features, 1).flatten(1))
        elif self.architecture == 'squeezenet':
            features = net.features(images)
            logits = net.classifier(features).flatten(1)
        elif self.architecture == 'efficientnet_lite0':
            features = net.forward_features(images)
            logits = net.forward_head(features)
        else:
            features = net.features(images)
            logits = net.classifier(F.adaptive_avg_pool2d(features, 1).flatten(1))
        return features, logits

    def forward(self, images):
        return self.features_logits(images)[1]


def activation(name):
    choices = {'relu': nn.ReLU, 'relu6': nn.ReLU6, 'silu': nn.SiLU, 'hardswish': nn.Hardswish}
    if name not in choices:
        raise ValueError('Unknown activation: ' + name)
    return choices[name](inplace=False)


class SearchCNN(nn.Module):
    def __init__(self, configuration, classes=10):
        super().__init__()
        blocks = configuration['blocks']
        if not 2 <= len(blocks) <= 5 or configuration['resolution'] not in (16, 24, 32):
            raise ValueError('Architecture outside the declared search space.')
        layers, incoming = [], 3
        for index, block in enumerate(blocks):
            channels, kernel = block['channels'], block['kernel']
            if channels not in (16, 24, 32, 48, 64, 96, 128) or kernel not in (3, 5, 7):
                raise ValueError('Invalid channels or kernel.')
            stride = 2 if index % 2 == 1 else 1
            if block['operation'] == 'separable':
                layers += [nn.Conv2d(incoming, incoming, kernel, stride, kernel // 2, groups=incoming, bias=False),
                           nn.BatchNorm2d(incoming), activation(block['activation']),
                           nn.Conv2d(incoming, channels, 1, bias=False)]
            elif block['operation'] == 'conv':
                layers += [nn.Conv2d(incoming, channels, kernel, stride, kernel // 2, bias=False)]
            else:
                raise ValueError('Unknown convolution operation.')
            layers += [nn.BatchNorm2d(channels), activation(block['activation'])]
            incoming = channels
        self.features = nn.Sequential(*layers)
        self.classifier = nn.Linear(incoming, classes)

    def forward(self, images):
        return self.classifier(F.adaptive_avg_pool2d(self.features(images), 1).flatten(1))


def sample_architecture(trial):
    depth = trial.suggest_int('depth', 2, 5)
    return {'resolution': trial.suggest_categorical('resolution', [16, 24, 32]), 'blocks': [
        {'channels': trial.suggest_categorical(f'channels_{i}', [16, 24, 32, 48, 64, 96, 128]),
         'kernel': trial.suggest_categorical(f'kernel_{i}', [3, 5, 7]),
         'operation': trial.suggest_categorical(f'operation_{i}', ['conv', 'separable']),
         'activation': trial.suggest_categorical(f'activation_{i}', ['relu', 'relu6', 'silu', 'hardswish'])}
        for i in range(depth)]}
