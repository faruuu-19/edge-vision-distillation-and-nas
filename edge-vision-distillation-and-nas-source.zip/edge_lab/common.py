import hashlib
import json
import os
import random
import time
from datetime import datetime, timezone
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
ROOT = Path(os.environ.get('EDGE_RUN_DIR', PROJECT)).resolve()
ROOT.mkdir(parents=True, exist_ok=True)


def timestamp():
    return datetime.now(timezone.utc).isoformat()


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False), encoding='utf-8')
    replace_file(temporary,path)


def replace_file(source, destination):
    # OneDrive/antivirus can briefly hold a Windows file across atomic replacements.
    for attempt in range(7):
        try:
            Path(source).replace(destination)
            return
        except PermissionError:
            if attempt==6:raise
            time.sleep(min(.1*2**attempt,2))


def seed_all(seed, threads=4):
    import numpy as np
    import torch
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if hasattr(torch, 'xpu') and torch.xpu.is_available():
        torch.xpu.manual_seed_all(seed)
    torch.set_num_threads(threads)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True


def sha256(path):
    digest = hashlib.sha256()
    with open(path, 'rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def state_hash(model):
    digest = hashlib.sha256()
    for name, tensor in model.state_dict().items():
        digest.update(name.encode())
        digest.update(tensor.detach().cpu().contiguous().numpy().tobytes())
    return digest.hexdigest()


def load_config(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def resolve_device(requested):
    import torch
    if requested == 'auto':
        if torch.cuda.is_available(): return torch.device('cuda')
        if hasattr(torch,'xpu') and torch.xpu.is_available(): return torch.device('xpu')
        if hasattr(torch.backends,'mps') and torch.backends.mps.is_available(): return torch.device('mps')
        return torch.device('cpu')
    if requested == 'cuda' and not torch.cuda.is_available():
        raise RuntimeError('CUDA requested but unavailable; choose cpu or a GPU runtime.')
    if requested == 'xpu' and not (hasattr(torch, 'xpu') and torch.xpu.is_available()):
        raise RuntimeError('Intel GPU unavailable. Install the XPU PyTorch build and Intel graphics driver; run SETUP_INTEL.cmd.')
    return torch.device(requested)
