"""Exercise actual forward/backward operations before a long training run."""
import gc
import json
import torch
from .common import resolve_device, seed_all
from .models import Classifier, STUDENTS
from .losses import DistillationLoss
from .pipeline import hardware


def check(require_xpu=False):
    device=resolve_device('xpu' if require_xpu else 'auto')
    seed_all(42,4)
    print(json.dumps(hardware(device),indent=2),flush=True)
    for architecture in ('resnet50',)+STUDENTS:
        model=Classifier(architecture,100).to(device).train()
        images=torch.randn(2,3,32,32,device=device)
        features,logits=model.features_logits(images)
        loss=torch.nn.functional.cross_entropy(logits,torch.tensor([0,1],device=device))
        if architecture!='resnet50':
            criterion=DistillationLoss(model.feature_channels,1024).to(device)
            loss,_=criterion(logits,torch.randn_like(logits),torch.tensor([0,1],device=device),
                features,torch.randn(2,1024,2,2,device=device))
            del criterion
        loss.backward()
        if not torch.isfinite(loss):raise RuntimeError('Preflight loss is not finite: '+architecture)
        print('PASS forward/backward:',architecture,str(device),flush=True)
        del model,features,logits,loss,images;gc.collect()
        if device.type=='xpu':torch.xpu.empty_cache()
    print('Preflight passed. These are synthetic compatibility checks, not trained-model results.',flush=True)
