"""Fresh-process ONNX CPU benchmark: excludes torch and captures process high-water memory."""
import argparse
import json
import platform
import time
import numpy as np
import onnxruntime as ort


def benchmark(path, resolution, threads=4, warmup=10, repeats=50):
    options = ort.SessionOptions()
    options.intra_op_num_threads = threads
    options.inter_op_num_threads = 1
    session = ort.InferenceSession(str(path), sess_options=options, providers=['CPUExecutionProvider'])
    images = np.random.default_rng(42).normal(size=(1,3,resolution,resolution)).astype(np.float32)
    inputs = {session.get_inputs()[0].name:images}
    for _ in range(warmup):
        session.run(None, inputs)
    timings = []
    for _ in range(repeats):
        start = time.perf_counter_ns()
        session.run(None, inputs)
        timings.append((time.perf_counter_ns()-start)/1e6)
    peak, method = None, 'unsupported'
    try:
        import psutil
        info = psutil.Process().memory_info()
        if hasattr(info,'peak_wset'):
            peak, method = info.peak_wset, 'Windows process peak working set'
        else:
            import resource
            value = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
            peak = value if platform.system()=='Darwin' else value*1024
            method = 'Process ru_maxrss high-water mark'
    except (ImportError, AttributeError, OSError):
        pass
    return {'latency_mean_ms':float(np.mean(timings)),'latency_median_ms':float(np.median(timings)),
        'latency_p95_ms':float(np.percentile(timings,95)),'latency_std_ms':float(np.std(timings)),
        'peak_memory_bytes':peak,'memory_method':method,'memory_scope':'Whole isolated inference process, including model and runtime; not a tensor-only allocation estimate.',
        'warmup':warmup,'repeats':repeats,'batch_size':1,'resolution':resolution,'threads':threads,
        'provider':session.get_providers()[0],'onnxruntime_version':ort.__version__,'raw_latency_ms':timings}


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('path');parser.add_argument('--resolution',type=int,required=True)
    parser.add_argument('--threads',type=int,default=4);parser.add_argument('--repeats',type=int,default=50)
    args=parser.parse_args()
    print(json.dumps(benchmark(args.path,args.resolution,args.threads,repeats=args.repeats)))
