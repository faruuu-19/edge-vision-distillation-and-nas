import torch
from torch import nn
from torch.nn import functional as F


class DistillationLoss(nn.Module):
    def __init__(self, student_channels, teacher_channels=1024, temperature=4.0, alpha=0.7, beta=1.0):
        super().__init__()
        if temperature <= 0 or not 0 <= alpha <= 1 or beta < 0:
            raise ValueError('Invalid distillation coefficients.')
        self.temperature, self.alpha, self.beta = temperature, alpha, beta
        self.projector = nn.Conv2d(student_channels, teacher_channels, 1, bias=False)

    def forward(self, student_logits, teacher_logits, labels, student_features, teacher_features):
        temperature = self.temperature
        hard = F.cross_entropy(student_logits, labels)
        soft = F.kl_div(F.log_softmax(student_logits / temperature, dim=1),
                        F.softmax(teacher_logits.detach() / temperature, dim=1), reduction='batchmean') * temperature ** 2
        projected = self.projector(student_features)
        aligned = F.adaptive_avg_pool2d(projected, teacher_features.shape[-2:])
        feature = F.mse_loss(F.normalize(aligned, dim=1), F.normalize(teacher_features.detach(), dim=1))
        total = (1 - self.alpha) * hard + self.alpha * soft + self.beta * feature
        return total, {'hard': hard.detach(), 'soft': soft.detach(), 'feature': feature.detach()}
