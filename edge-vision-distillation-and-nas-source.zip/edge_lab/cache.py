"""Optional frozen-teacher targets for exactly matching deterministic images."""
import hashlib
import json
import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader
from .common import ROOT, write_json, sha256


def index_hash(indices):
    return hashlib.sha256(np.array(indices,dtype=np.int64).tobytes()).hexdigest()


def build_targets(data, teacher_path, device, batch_size=64, threads=4):
    from .train import load_checkpoint
    torch.set_num_threads(threads)
    folder=ROOT/'.runs'/'teacher_targets';folder.mkdir(parents=True,exist_ok=True)
    teacher,metadata=load_checkpoint(teacher_path,device)
    teacher.eval().requires_grad_(False)
    train,_,_=data.loaders(32,batch_size,augment=False)
    loader=DataLoader(train.dataset,batch_size=batch_size,shuffle=False,num_workers=0)
    logits_store,features_store=None,None
    offset=0
    with torch.inference_mode():
        for images,_ in loader:
            features,logits=teacher.features_logits(images.to(device))
            if logits_store is None:
                logits_store=np.lib.format.open_memmap(folder/'logits.npy',mode='w+',dtype=np.float16,shape=(len(train.dataset),logits.shape[1]))
                features_store=np.lib.format.open_memmap(folder/'features.npy',mode='w+',dtype=np.float16,shape=(len(train.dataset),*features.shape[1:]))
                feature_shape=list(features.shape[1:])
            size=len(images)
            logits_store[offset:offset+size]=logits.cpu().numpy().astype(np.float16)
            features_store[offset:offset+size]=features.cpu().numpy().astype(np.float16)
            offset+=size
            if offset%4096==0:print('Cached genuine teacher targets:',offset,flush=True)
    logits_store.flush();features_store.flush()
    write_json(folder/'metadata.json',{'teacher_sha256':sha256(teacher_path),'indices_sha256':index_hash(data.train_indices),
        'normalization':{'mean':data.mean,'std':data.std},'samples':offset,'feature_shape':feature_shape,
        'dtype':'float16','augmentation':False,'note':'Targets generated from the same unaugmented training images used by every CPU-profile student; converted to float32 for the loss.'})
    return folder


class CachedTargets(Dataset):
    def __init__(self, images, folder, teacher_path):
        self.images=images
        metadata=json.loads((folder/'metadata.json').read_text())
        if metadata['indices_sha256']!=index_hash(images.indices) or metadata['teacher_sha256']!=sha256(teacher_path):
            raise ValueError('Teacher target cache does not match dataset ordering or checkpoint.')
        self.logits=np.load(folder/'logits.npy',mmap_mode='r')
        self.features=np.load(folder/'features.npy',mmap_mode='r')

    def __len__(self):return len(self.images)

    def __getitem__(self,index):
        image,label=self.images[index]
        return image,label,torch.from_numpy(np.array(self.logits[index],dtype=np.float32)),torch.from_numpy(np.array(self.features[index],dtype=np.float32))
