import csv
import json
import platform
import sys
from pathlib import Path
import torch
from .common import ROOT, PROJECT, load_config, resolve_device, timestamp, write_json, sha256, seed_all
from .models import STUDENTS


def hardware(device):
    import importlib.metadata
    import os
    import psutil
    processor=platform.processor()
    if sys.platform=='win32':
        import winreg
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,r'HARDWARE\DESCRIPTION\System\CentralProcessor\0') as key:
            processor=winreg.QueryValueEx(key,'ProcessorNameString')[0].strip()
    accelerator=None
    if device.type=='cuda':accelerator=torch.cuda.get_device_name(device)
    elif device.type=='xpu':accelerator=torch.xpu.get_device_name(device)
    return {'captured_utc':timestamp(),'os':platform.platform(),'python':platform.python_version(),
        'cpu':processor,'logical_cpus':os.cpu_count(),'ram_bytes':psutil.virtual_memory().total,
        'training_device':str(device),'accelerator':accelerator,'torch':str(torch.__version__),
        'versions':{name:importlib.metadata.version(name) for name in ('torchvision','timm','onnx','onnxruntime','optuna','numpy','psutil')}}


def run_all(config_path, resume=False, require_accelerator=False):
    from .data import CIFARData
    from .train import train_model
    from .cache import build_targets
    from .deploy import export_checkpoint
    from .nas import search
    configuration=load_config(config_path)
    seed_all(configuration['seed'],configuration['threads'])
    device=resolve_device(configuration['device'])
    if require_accelerator and device.type=='cpu':
        raise RuntimeError('No supported training GPU detected. Install the correct CUDA/XPU/Metal-enabled PyTorch build. An NPU alone is not a PyTorch training GPU. Use the cpu profile explicitly if intended.')
    for name in ('models','onnx','results','.runs'):(ROOT/name).mkdir(exist_ok=True)
    manifest_path=ROOT/'results'/'run_manifest.json'
    fingerprint=sha256(config_path)
    if manifest_path.exists():
        manifest=json.loads(manifest_path.read_text())
        if not resume:raise RuntimeError('An experiment already exists. Use --resume for the same configuration or --output-root for an independent run.')
        if manifest['configuration_sha256']!=fingerprint:raise RuntimeError('Configuration changed. Use a separate --output-root; do not mix experiments.')
    else:
        manifest={'configuration_sha256':fingerprint,'configuration':configuration,'started_utc':timestamp(),'completed_stages':[],'status':'running'}
    write_json(ROOT/'results'/'hardware.json',hardware(device))
    write_json(manifest_path,manifest)
    def stage(name, operation):
        if name in manifest['completed_stages']:
            expected=[]
            if name=='teacher' or name.endswith(('_baseline','_kd')):
                expected=[ROOT/'models'/(name+'.pt'),ROOT/'results'/(name+'_metrics.json')]
            elif name.endswith('_onnx'):
                expected=[ROOT/'onnx'/(name[:-5]+'.onnx'),ROOT/'onnx'/(name[:-5]+'.json')]
            elif name=='nas':
                expected=[ROOT/'models/nas_best.pt',ROOT/'onnx/nas_best.onnx',ROOT/'results/nas_final_verification.json']
            elif name=='benchmark_summary':
                expected=[ROOT/'results/benchmarks.csv',ROOT/'results/benchmarks.json']
            if any(not path.is_file() for path in expected):
                raise RuntimeError('Completed stage has missing artifacts: '+name+'. Restore them or use an independent output directory.')
            print('RESUME: completed stage',name,flush=True);return
        manifest['current_stage']=name;manifest['status']='running';write_json(manifest_path,manifest)
        print('START:',name,flush=True)
        operation()
        manifest['completed_stages'].append(name);write_json(manifest_path,manifest)
    cifar100=CIFARData('cifar100',configuration['seed'])
    teacher_settings={**configuration['teacher'],'threads':configuration['threads']}
    student_settings={**configuration['student'],'threads':configuration['threads']}
    teacher_path=ROOT/'models'/'teacher.pt'
    try:
        stage('teacher',lambda:train_model('teacher','resnet50',cifar100,teacher_settings,device,seed=configuration['seed']))
        if student_settings.get('cache_teacher'):
            stage('teacher_targets',lambda:build_targets(cifar100,teacher_path,device,student_settings['batch_size'],configuration['threads']))
        for architecture in STUDENTS:
            stage(architecture+'_baseline',lambda architecture=architecture:train_model(architecture+'_baseline',architecture,cifar100,
                {**student_settings,'cache_teacher':False},device,seed=configuration['seed']))
            stage(architecture+'_kd',lambda architecture=architecture:train_model(architecture+'_kd',architecture,cifar100,
                student_settings,device,teacher_path=teacher_path,seed=configuration['seed']))
            for mode in ('baseline','kd'):
                name=architecture+'_'+mode
                stage(name+'_onnx',lambda name=name:export_checkpoint(ROOT/'models'/(name+'.pt'),configuration['threads']))
        from PIL import Image
        sample_dir=ROOT/'docs'/'samples';sample_dir.mkdir(parents=True,exist_ok=True)
        Image.fromarray(cifar100.test.data[0]).save(sample_dir/'cifar100_test_0.png')
        cifar100_label=cifar100.classes[cifar100.test.targets[0]]
        del cifar100
        import gc
        gc.collect()
        cifar10=CIFARData('cifar10',configuration['seed'])
        stage('nas',lambda:search(cifar10,configuration,device))
        Image.fromarray(cifar10.test.data[0]).save(sample_dir/'cifar10_test_0.png')
        from .deploy import predict
        examples=[]
        for name in [a+'_'+mode for a in STUDENTS for mode in ('baseline','kd')]+['nas_best']:
            image=sample_dir/('cifar10_test_0.png' if name=='nas_best' else 'cifar100_test_0.png')
            examples.append({'model':name,'image':str(image.relative_to(ROOT)),
                'true_label':cifar10.classes[cifar10.test.targets[0]] if name=='nas_best' else cifar100_label,
                'torch_top5':predict(ROOT/'models'/(name+'.pt'),image),
                'onnx_top5':predict(ROOT/'onnx'/(name+'.onnx'),image,onnx=True)})
        write_json(ROOT/'results'/'inference_examples.json',examples)
        stage('benchmark_summary',summarize)
        manifest.pop('error_type',None)
        manifest['status']='training_complete';manifest['finished_utc']=timestamp();write_json(manifest_path,manifest)
        from .report import build_report
        build_report()
        from .submission import package
        if not configuration.get('smoke'):package()
    except BaseException as exc:
        manifest['status']='interrupted' if isinstance(exc,KeyboardInterrupt) else 'failed'
        manifest['error_type']=type(exc).__name__;write_json(manifest_path,manifest)
        raise


def summarize():
    rows=[]
    for name in [a+'_'+mode for a in STUDENTS for mode in ('baseline','kd')]+['nas_best']:
        measurement=json.loads((ROOT/'results'/(name+'_benchmark.json')).read_text())
        metrics=json.loads((ROOT/'results'/(name+'_metrics.json')).read_text())
        rows.append({'model':name,'dataset':metrics['dataset'],'epochs':metrics['epochs'],
            'validation_accuracy':metrics['validation']['top1'],'test_accuracy':metrics['test']['top1'],
            'parameters':metrics['parameter_count'],'training_seconds':metrics['training_seconds'],
            **{key:measurement[key] for key in ('model_bytes','latency_mean_ms','latency_median_ms','latency_p95_ms','peak_memory_bytes','provider','threads','parity_max_absolute_error')}})
    with (ROOT/'results'/'benchmarks.csv').open('w',newline='',encoding='utf-8') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    write_json(ROOT/'results'/'benchmarks.json',rows)
    return rows
