"""Edge Computing Assignment 04: distillation, measured NAS and deployment."""
